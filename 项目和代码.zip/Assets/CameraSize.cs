using UnityEngine;

public class CameraAdapter : MonoBehaviour
{
    public float fixedWidth = 1200; // 固定宽度值
    private Camera mainCamera;

    void Start()
    {
        mainCamera = Camera.main;
        AdjustCameraSize();
    }

    void Update()
    {
        AdjustCameraSize();
    }

    void AdjustCameraSize()
    {
        float screenWidth = Screen.width;
        float screenHeight = Screen.height;
        float targetHeight = fixedWidth * (screenHeight / screenWidth);
        mainCamera.orthographicSize = targetHeight / 2f;
    }
}