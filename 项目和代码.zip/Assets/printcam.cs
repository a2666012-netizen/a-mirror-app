
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Android;

public class printcam : MonoBehaviour
{
    public RawImage rawImage;
    private WebCamTexture webCamTexture;
    
    void Start()
    {
        StartCoroutine(StartCam());
    }

    IEnumerator StartCam()
    {
#if UNITY_ANDROID
        // 检查并请求相机权限
        if (!Permission.HasUserAuthorizedPermission(Permission.Camera))
        {
            Permission.RequestUserPermission(Permission.Camera);
            yield return new WaitForSeconds(0.5f);
        }
#endif

        yield return Application.RequestUserAuthorization(UserAuthorization.WebCam);
        WebCamDevice[] devices = WebCamTexture.devices;
        webCamTexture = new WebCamTexture(devices[1].name);
        rawImage.texture = webCamTexture;
        webCamTexture.Play();
    }

    void Update()
    {
        
    }
}
